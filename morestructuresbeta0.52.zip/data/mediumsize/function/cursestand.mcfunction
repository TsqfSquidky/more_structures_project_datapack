execute at @e[tag=Cursed] run particle minecraft:smoke ~ ~1 ~ 4 4 4 0 50 force
execute at @e[tag=Cursed] run effect give @a[distance=..6] minecraft:bad_omen 6000 5