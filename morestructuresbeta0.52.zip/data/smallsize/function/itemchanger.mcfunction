
# Medium Scout Camp

item replace entity @e[tag=VinSword] weapon.mainhand with minecraft:iron_sword[minecraft:attribute_modifiers={modifiers:[{type:"generic.attack_damage", amount:12, operation:add_value, id:"vinsword"}]}, item_name='{"text":"Golem Gutter", "italic":false}']
execute as @e[tag=VinSword] run data modify entity @s HandDropChances set value [0.35f, 0f]
item replace entity @e[tag=WatchIllu] weapon.mainhand with minecraft:bow[enchantments={levels:{punch:1, flame:1}}]

tag @e[tag=VinSword] remove VinSword
tag @e[tag=WatchIllu] remove WatchIllu

# desert titan

item replace entity @e[tag=titanguard] weapon.mainhand with minecraft:crossbow[enchantments={levels:{multishot:1, piercing:2, quick_charge:3}}]
tag @e[tag=titanguard] remove titanguard

effect give @e[tag=desertgiant] fire_resistance infinite