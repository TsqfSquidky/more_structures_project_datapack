## Mob Tower

execute as @e[tag=towerguard] run data modify entity @s CustomName set value '{"text":"Tower Guard", "color":"gray", "bold":true}'
item replace entity @e[tag=towerguard] armor.chest with minecraft:iron_chestplate
item replace entity @e[tag=towerguard] armor.head with minecraft:iron_helmet
item replace entity @e[tag=towerguard] armor.feet with minecraft:iron_boots
item replace entity @e[tag=towerguard] armor.legs with minecraft:iron_leggings
item replace entity @e[tag=towerguard] weapon.mainhand with minecraft:iron_sword[minecraft:enchantments={levels:{"customfeatures:decay":1, "customfeatures:venombite":1,"minecraft:sharpness":4}}]

execute as @e[tag=tower_roof_boss1] run data modify entity @s CustomName set value '{"text":"Tower Captain", "bold":true}'
execute as @e[tag=tower_roof_boss1] run data modify entity @s HandDropChances set value [0.25f, 0f]
item replace entity @e[tag=tower_roof_boss1] armor.chest with minecraft:diamond_chestplate
item replace entity @e[tag=tower_roof_boss1] armor.head with minecraft:diamond_helmet
item replace entity @e[tag=tower_roof_boss1] armor.feet with minecraft:diamond_boots
item replace entity @e[tag=tower_roof_boss1] armor.legs with minecraft:diamond_leggings
item replace entity @e[tag=tower_roof_boss1] weapon.mainhand with minecraft:netherite_sword[minecraft:enchantments={levels:{"customfeatures:decay":2, "customfeatures:venombite":2,"minecraft:sharpness":7}}]

execute as @e[tag=tower_roof_boss2] run data modify entity @s CustomName set value '{"text":"Tower Captain", "bold":true}'
execute as @e[tag=tower_roof_boss2] run data modify entity @s HandDropChances set value [0.25f, 0f]
item replace entity @e[tag=tower_roof_boss2] armor.chest with minecraft:diamond_chestplate
item replace entity @e[tag=tower_roof_boss2] armor.head with minecraft:diamond_helmet
item replace entity @e[tag=tower_roof_boss2] armor.feet with minecraft:diamond_boots
item replace entity @e[tag=tower_roof_boss2] armor.legs with minecraft:diamond_leggings
item replace entity @e[tag=tower_roof_boss2] weapon.mainhand with bow[minecraft:enchantments={levels:{"minecraft:power":7, "minecraft:piercing":3}}]

tag @e[tag=towerguard] remove towerguard
tag @e[tag=tower_roof_boss1] remove tower_roof_boss1
tag @e[tag=tower_roof_boss2] remove tower_roof_boss2


## Stray Outpost

execute as @e[type=stray, tag=outpost_commander] at @s run attribute @s minecraft:generic.max_health base set 85
execute as @e[type=stray, tag=outpost_commander_ranged] at @s run attribute @s minecraft:generic.max_health base set 70

execute as @e[type=stray, tag=outpost_commander] at @s run data modify entity @s Health set value 85
execute as @e[type=stray, tag=outpost_commander_ranged] at @s run data modify entity @s Health set value 70

execute as @e[type=stray, tag=meleeguard] at @s run attribute @s minecraft:generic.max_health base set 25
execute as @e[type=stray, tag=meleeguard] at @s run data modify entity @s Health set value 25

execute as @e[type=stray, tag=towerwatch] at @s run attribute @s minecraft:generic.max_health base set 30
execute as @e[type=stray, tag=towerwatch] at @s run data modify entity @s Health set value 30

item replace entity @e[type=stray, tag=outpost_commander] armor.feet with minecraft:iron_boots[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=outpost_commander_ranged] armor.feet with minecraft:iron_boots[enchantments={levels:{protection:3}}]

item replace entity @e[type=stray, tag=outpost_commander] armor.legs with minecraft:iron_leggings[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=outpost_commander_ranged] armor.legs with minecraft:iron_leggings[enchantments={levels:{protection:3}}]

item replace entity @e[type=stray, tag=outpost_commander] armor.chest with minecraft:iron_chestplate[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=outpost_commander_ranged] armor.chest with minecraft:iron_chestplate[enchantments={levels:{protection:3}}]

item replace entity @e[type=stray, tag=outpost_commander] armor.head with minecraft:iron_helmet[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=outpost_commander_ranged] armor.head with minecraft:iron_helmet[enchantments={levels:{protection:3}}]

item replace entity @e[type=stray, tag=meleeguard] armor.feet with minecraft:leather_boots[enchantments={levels:{protection:2}}]
item replace entity @e[type=stray, tag=meleeguard] armor.legs with minecraft:leather_leggings[enchantments={levels:{protection:2}}]
item replace entity @e[type=stray, tag=meleeguard] armor.chest with minecraft:leather_chestplate[enchantments={levels:{protection:2}}]
item replace entity @e[type=stray, tag=meleeguard] armor.head with minecraft:leather_helmet[enchantments={levels:{protection:2}}]

item replace entity @e[type=stray, tag=towerwatch] armor.feet with minecraft:chainmail_boots[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=towerwatch] armor.legs with minecraft:chainmail_leggings[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=towerwatch] armor.chest with minecraft:chainmail_chestplate[enchantments={levels:{protection:3}}]
item replace entity @e[type=stray, tag=towerwatch] armor.head with minecraft:chainmail_helmet[enchantments={levels:{protection:3}}]

item replace entity @e[type=stray, tag=towerwatch] weapon.mainhand with minecraft:bow[enchantments={levels:{punch:3}}]
item replace entity @e[type=stray, tag=meleeguard] weapon.mainhand with minecraft:wooden_axe[enchantments={levels:{"customfeatures:torque":2, "customfeatures:freezing_strike":2}}]
item replace entity @e[type=stray, tag=outpost_commander] weapon.mainhand with minecraft:diamond_sword[max_damage=2000, enchantments={levels:{"customfeatures:razor":4, "customfeatures:freezing_strike":3}}, attribute_modifiers={modifiers:[{type:"generic.armor",amount:2,slot:mainhand,id:armoing,operation:add_value},{type:"player.sweeping_damage_ratio",amount:0.2,slot:mainhand,id:sweeing,operation:add_value},{type:"generic.attack_damage",amount:9.5,slot:mainhand,id:damaging,operation:add_value},{type:"generic.attack_speed",amount:-0.3,operation:add_multiplied_base,id:attackspeed}]}]
item replace entity @e[type=stray, tag=outpost_commander_ranged] weapon.mainhand with minecraft:bow[enchantments={levels:{power:5, flame:1}}, minecraft:custom_name='{"text":"Ice Crystal Blade", "color":"#3399ff", "italic":false}']

tag @e[tag=towerwatch] remove towerwatch
tag @e[tag=meleeguard] remove meleeguard
tag @e[tag=outpost_commander] remove outpost_commander
tag @e[tag=outpost_commander_ranged] remove outpost_commander_ranged